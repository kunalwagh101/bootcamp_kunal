from ex1_3_command.hello import app

def main():
  app()

if __name__ == "__main__" :
    print(main())
    