import sqlite3
from typing import Any
from persistent_map import Persistent_blueprint


DB_FILE = "queue.db"
MAX_ATTEMPTS = 3      
TIMEOUT_SECONDS = 60  



class PersistentQSQLite(Persistent_blueprint):

    def __init__(self, db_file: str = DB_FILE):
        self.db_file = db_file
        self._initialize_db()

    def _initialize_db(self):
        conn = sqlite3.connect(self.db_file)
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                job_id TEXT PRIMARY KEY,
                job_data TEXT,
                status TEXT,
                attempts INTEGER DEFAULT 0,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                consumer_id TEXT DEFAULT NULL
            )
        """)
        conn.commit()
        conn.close()

    def enqueue(self, job_id: str, job_data: Any) -> None:
        conn = sqlite3.connect(self.db_file)
        c = conn.cursor()
        c.execute("""
            INSERT OR IGNORE INTO jobs (job_id, job_data, status, attempts, last_updated, consumer_id)
            VALUES (?, ?, 'pending', 0, CURRENT_TIMESTAMP, NULL)
        """, (job_id, str(job_data)))
        conn.commit()
        conn.close()

    def cleanup_stuck_jobs(self, timeout: int = TIMEOUT_SECONDS, max_attempts: int = MAX_ATTEMPTS) -> None:
        """
        Reset jobs stuck in 'processing' state beyond the timeout..
        """
        conn = sqlite3.connect(self.db_file)
        c = conn.cursor()
    
        c.execute(f"""
            UPDATE jobs 
            SET status = 'pending', last_updated = CURRENT_TIMESTAMP, consumer_id = NULL 
            WHERE status = 'processing'
              AND last_updated < datetime('now', '-{timeout} seconds')
              AND attempts < ?
        """, (max_attempts,))
    
        c.execute(f"""
            UPDATE jobs 
            SET status = 'failed', last_updated = CURRENT_TIMESTAMP, consumer_id = NULL 
            WHERE status = 'processing'
              AND last_updated < datetime('now', '-{timeout} seconds')
              AND attempts >= ?
        """, (max_attempts,))
        conn.commit()
        conn.close()

    def dequeue(self, consumer_id: str) :
     
        self.cleanup_stuck_jobs()

        conn = sqlite3.connect(self.db_file)
        conn.isolation_level = None  
        c = conn.cursor()
        try:
            c.execute("BEGIN EXCLUSIVE")
            c.execute("SELECT job_id, job_data, attempts FROM jobs WHERE status = 'pending' LIMIT 1")
            row = c.fetchone()
            if row:
                job_id, job_data, attempts = row
                new_attempts = attempts + 1
                if new_attempts > MAX_ATTEMPTS:
                
                    c.execute("""
                        UPDATE jobs 
                        SET status = 'failed', attempts = ?, last_updated = CURRENT_TIMESTAMP, consumer_id = ?
                        WHERE job_id = ?
                    """, (new_attempts, consumer_id, job_id))
                    conn.commit()
                    return None
                else:
                    c.execute("""
                        UPDATE jobs 
                        SET status = 'processing', attempts = ?, last_updated = CURRENT_TIMESTAMP, consumer_id = ?
                        WHERE job_id = ?
                    """, (new_attempts, consumer_id, job_id))
                    conn.commit()
                    return job_id, job_data
            conn.commit()
        except Exception as e:
            conn.rollback()
            raise e
        finally:
            conn.close()
        return None

    def update_job_status(self, job_id: str, status: str):
        conn = sqlite3.connect(self.db_file)
        c = conn.cursor()
        new_consumer = None if status != 'processing' else ""
        c.execute("""
            UPDATE jobs 
            SET status = ?, last_updated = CURRENT_TIMESTAMP, consumer_id = ?
            WHERE job_id = ?
        """, (status, new_consumer, job_id))
        conn.commit()
        conn.close()

    def get_job_status(self, job_id: str) :
        conn = sqlite3.connect(self.db_file)
        c = conn.cursor()
        c.execute("SELECT status FROM jobs WHERE job_id = ?", (job_id,))
        row = c.fetchone()
        conn.close()
        return row[0] if row else None

    def get_attempts(self, job_id: str) :
        conn = sqlite3.connect(self.db_file)
        c = conn.cursor()
        c.execute("SELECT attempts FROM jobs WHERE job_id = ?", (job_id,))
        row = c.fetchone()
        conn.close()
        return row[0] if row else 0

    def list_jobs(self) :
        conn = sqlite3.connect(self.db_file)
        c = conn.cursor()
        c.execute("SELECT job_id, job_data, status FROM jobs")
        rows = c.fetchall()
        conn.close()
        return rows


if __name__ =="__main__" :
    p = PersistentQSQLite()
    print(p.enqueue("/mnt/h/Aganitha/bootcamp/PersistentQSQLite/job_1740397874_khiwz.txt","/mnt/h/Aganitha/bootcamp/PersistentQSQLite/job_1740397874_khiwz.txt"))
    print(p.get_job_status("/mnt/h/Aganitha/bootcamp/PersistentQSQLite/job_1740397874_khiwz.txt"))



# class PersistentQSQLite(Persistent_blueprint):
#     def __init__(self, db_file: str = DB_FILE):
#         self.db_file = db_file
#         self._initialize_db()

#     def _initialize_db(self):
#         connection = sqlite3.connect(self.db_file)
#         c = connection.cursor()
#         c.execute("""
#             CREATE TABLE IF NOT EXISTS jobs (
#                 job_id TEXT PRIMARY KEY,
#                 job_data TEXT,
#                 status TEXT
#             )
#         """)
#         connection.commit()
#         connection.close()

#     def enqueue(self, job_id: str, job_data: Any) :
#         connection = sqlite3.connect(self.db_file)
#         try:
#             c = connection.cursor()
#             c.execute("BEGIN IMMEDIATE")
#             c.execute("INSERT OR IGNORE INTO jobs (job_id, job_data, status) VALUES (?, ?, ?)",
#                       (job_id, str(job_data), "pending"))
#             connection.commit()
#         except Exception as e:
#             connection.rollback()
#             raise e
#         finally:
#             connection.close()

#     def dequeue(self) :
#         connection = sqlite3.connect(self.db_file)
#         try:
#             c = connection.cursor()
#             c.execute("BEGIN IMMEDIATE")
#             c.execute("SELECT job_id, job_data FROM jobs WHERE status = 'pending' LIMIT 1")
#             row = c.fetchone()
#             if row:
#                 job_id, job_data = row
#                 c.execute("UPDATE jobs SET status = 'processing' WHERE job_id = ?", (job_id,))
#                 connection.commit()
#                 return job_id, job_data
#             connection.commit()
#         except Exception as e:
#             connection.rollback()
#             raise e
#         finally:
#             connection.close()
#         return None

#     def update_job_status(self, job_id: str, status: str):
#         connection = sqlite3.connect(self.db_file)
#         try:
#             c = connection.cursor()
#             c.execute("BEGIN IMMEDIATE")
#             c.execute("UPDATE jobs SET status = ? WHERE job_id = ?", (status, job_id))
#             connection.commit()
#         except Exception as e:
#             connection.rollback()
#             raise e
#         finally:
#             connection.close()

#     def get_job_status(self, job_id: str) -> Optional[str]:
#         connection = sqlite3.connect(self.db_file)
#         try:
#             c = connection.cursor()
#             c.execute("SELECT status FROM jobs WHERE job_id = ?", (job_id,))
#             row = c.fetchone()
#         finally:
#             connection.close()
#         return row[0] if row else None

#     def list_jobs(self) :
#         connection = sqlite3.connect(self.db_file)
#         try:
#             c = connection.cursor()
#             c.execute("SELECT job_id, job_data, status FROM jobs")
#             rows = c.fetchall()
#         finally:
#             connection.close()
#         return rows