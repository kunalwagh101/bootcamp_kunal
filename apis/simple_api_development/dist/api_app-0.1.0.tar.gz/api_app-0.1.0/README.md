

## How to run the Api_App


- **Run the requirements.txt**

```
pip install requirements.txt
```

- **cd to Api_app**



```
  cd Api_app
```
- **run the app**
```
    uvicorn main:app --reload

```

## Contains :

- **main.py**     :  contain the routes , ex from 1 to 8
- **models.py**   : contain the database
- **database.py** : contain the config , also the Question no.5



## Run this urls like to test :

```

/test/create

```

```

```